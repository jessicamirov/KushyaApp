# KushyaApp
 Kushiya AI Generated Trivia App that utilizes AI to dynamically generate trivia questions and evaluate player responses. 
Designed with a unique blend of technology and creativity, Kushiya aims to bring an engaging and dynamic user experience to trivia enthusiasts.

OpenAI API: To handle real-time Trivia Generator and Smart Scoring System.


